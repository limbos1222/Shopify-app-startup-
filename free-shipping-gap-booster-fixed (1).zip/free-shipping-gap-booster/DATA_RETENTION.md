# Data Retention Policy — Free Shipping Gap Booster

| Data Type | Retention |
|---|---|
| Raw events (`EventRaw`) | 30 days |
| Session aggregates (`SessionCartAgg`) | 30 days |
| Daily aggregates (`DailyGapAgg`) | 13 months |
| Monthly session rows (`MonthlySession`) | 13 months |
| Pixel tokens (`PixelToken`) | 10 minutes |

Enforced by `npm run retention-cleanup` (schedule daily in production).
