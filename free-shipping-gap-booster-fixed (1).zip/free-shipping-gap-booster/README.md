# Free Shipping Gap Booster

An embedded Shopify app that tracks (via Web Pixel) sessions where customers stop within $1–$15 of the store's free-shipping threshold and reports:
- Near-threshold rate
- Average gap
- Estimated uplift opportunity
- Top products appearing in near-threshold sessions

## Quick start (dev)

1) Install deps

```bash
npm install
cp .env.example .env
```

2) Fill `.env`
- `SHOPIFY_API_KEY`
- `SHOPIFY_API_SECRET`
- `SHOPIFY_APP_URL` (Shopify CLI will usually set this automatically while running `shopify app dev`)

3) Init DB

```bash
npm run setup
```

4) Run

```bash
shopify app dev
```

## Rollups

Daily aggregates are computed by the rollup job.

During development (after generating some cart events), run:

```bash
npm run daily-rollup
```

And to enforce retention:

```bash
npm run retention-cleanup
```

## Notes

- Storefront tracking is via **Web Pixel** only (no theme edits).
- No PII stored; session IDs are SHA-256 hashed before DB persistence.
