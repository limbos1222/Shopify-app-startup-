# Terms of Service — Free Shipping Gap Booster

**Last updated:** 2026-02-25

This app provides analytics and recommendations. Revenue uplift values are estimates and not guarantees.
