/// <reference types="@remix-run/dev" />
/// <reference types="@remix-run/node" />

interface ImportMetaEnv {
  readonly VITE_SHOPIFY_API_KEY?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
