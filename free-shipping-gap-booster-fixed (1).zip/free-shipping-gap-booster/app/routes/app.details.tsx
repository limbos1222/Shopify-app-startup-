import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Card, Text, BlockStack, Banner, DataTable } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { db } from "~/db.server";
import { getAggregatedStats } from "~/lib/aggregation.server";
import { getMonthlySessionCount } from "~/lib/billing.server";
import { getPlan } from "~/lib/plans";
import { UpgradeBanner } from "~/components/UpgradeBanner";
import { format } from "date-fns";

function formatCurrency(cents: number, currency: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(cents / 100);
}

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = await db.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Response("Shop not found", { status: 404 });

  const url = new URL(request.url);
  const days = parseInt(url.searchParams.get("days") ?? "30", 10);
  const validDays = [7, 30].includes(days) ? days : 30;

  const stats = await getAggregatedStats(shop.id, validDays);
  const monthlySessionCount = await getMonthlySessionCount(shop.id);
  const plan = getPlan(shop.plan);
  const isLocked = monthlySessionCount > plan.sessionLimit;

  return json({
    stats,
    shop: { plan: shop.plan, currencyCode: shop.currencyCode },
    isLocked,
    plan,
    monthlySessionCount,
  });
};

export default function DetailsPage() {
  const { stats, shop, isLocked, plan, monthlySessionCount } = useLoaderData<typeof loader>();
  const currency = shop.currencyCode;

  const rows = stats.dailyRows.map((r) => [
    format(new Date(r.date), "MMM dd, yyyy"),
    r.cartSessions.toLocaleString(),
    r.nearThresholdSessions.toLocaleString(),
    formatCurrency(r.avgGapCents, currency),
    formatCurrency(r.estUpliftCents, currency),
  ]);

  return (
    <Page title="Analytics Details" subtitle="Daily breakdown of near-threshold cart sessions" backAction={{ content: "Dashboard", url: "/app" }}>
      <BlockStack gap="500">
        {isLocked && (
          <UpgradeBanner
            currentPlan={shop.plan}
            sessionCount={monthlySessionCount}
            sessionLimit={plan.sessionLimit}
          />
        )}

        {isLocked ? (
          <Banner tone="warning">Upgrade your plan to view the full daily breakdown.</Banner>
        ) : (
          <Card>
            <BlockStack gap="400">
              <Text as="h2" variant="headingMd">Daily Breakdown</Text>
              {rows.length === 0 ? (
                <Text as="p" variant="bodyMd" tone="subdued">
                  No daily aggregates yet. In development, run <code>npm run daily-rollup</code>.
                </Text>
              ) : (
                <DataTable
                  columnContentTypes={["text", "numeric", "numeric", "numeric", "numeric"]}
                  headings={["Date", "Cart Sessions", "Near-Threshold", "Avg Gap", "Est. Uplift"]}
                  rows={rows}
                />
              )}
            </BlockStack>
          </Card>
        )}

        <Card>
          <BlockStack gap="300">
            <Text as="h2" variant="headingMd">How We Calculate This</Text>
            <Text as="p" variant="bodyMd">
              <strong>Near-Threshold Cart:</strong> A browser session where the highest observed cart value was between $1 and $15 below your configured free-shipping threshold — and the session did not result in a purchase.
            </Text>
            <Text as="p" variant="bodyMd">
              <strong>Estimated Uplift:</strong> near-threshold sessions × avg gap × 0.35 (uplift factor). This is an estimate; results vary.
            </Text>
            <Text as="p" variant="bodyMd" tone="subdued">
              Events are collected via a Web Pixel and retained for 30 days. Aggregates are retained for 13 months. No PII is stored.
            </Text>
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
