import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { z } from "zod";
import { db } from "~/db.server";
import { issuePixelToken } from "~/lib/token.server";

const schema = z.object({
  shopDomain: z.string().min(1),
  pixelInstanceId: z.string().min(10),
});

function corsHeaders(request: Request): HeadersInit {
  const origin = request.headers.get("Origin") || "";

  // Some storefront/pixel contexts omit Origin. In that case, allow the request.
  if (!origin) {
    return {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Max-Age": "600",
    };
  }

  const allowed =
    origin === "https://cdn.shopify.com" ||
    /^https:\/\/.*\.myshopify\.com$/.test(origin) ||
    /^https:\/\/.*\.shopify\.com$/.test(origin);

  if (!allowed) {
    // No CORS for unknown origins
    return { "Vary": "Origin" };
  }

  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "600",
    "Vary": "Origin",
  };
}

export async function action({ request }: ActionFunctionArgs) {
  const headers = corsHeaders(request);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }

  if (request.method !== "POST") {
    return json({ error: "Method not allowed" }, { status: 405, headers });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Invalid JSON" }, { status: 400, headers });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return json({ error: "Invalid payload" }, { status: 400, headers });
  }

  const { shopDomain, pixelInstanceId } = parsed.data;

  const shop = await db.shop.findFirst({ where: { shopDomain, pixelInstanceId } });
  if (!shop) {
    return json({ error: "Unauthorized" }, { status: 401, headers });
  }

  const token = await issuePixelToken(shop.id);
  return json({ token }, { status: 200, headers });
}

export async function loader({ request }: LoaderFunctionArgs) {
  const headers = corsHeaders(request);
  return json({ error: "Not found" }, { status: 404, headers });
}
