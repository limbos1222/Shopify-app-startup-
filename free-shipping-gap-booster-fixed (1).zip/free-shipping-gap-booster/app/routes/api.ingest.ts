import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { z } from "zod";
import { validatePixelToken } from "~/lib/token.server";
import { processEvents } from "~/lib/ingest.server";

const eventSchema = z.object({
  type: z.string(),
  productId: z.string().optional(),
  variantId: z.string().optional(),
  qty: z.number().int().min(0).default(1),
  priceCents: z.number().int().min(0),
  ts: z.number().int(),
  path: z.string().optional(),
});

const payloadSchema = z.object({
  token: z.string().min(1),
  sessionId: z.string().uuid(),
  events: z.array(eventSchema).min(1).max(100),
});

function corsHeaders(request: Request): HeadersInit {
  const origin = request.headers.get("Origin") || "";

  // Some storefront/pixel contexts omit Origin. In that case, allow the request.
  if (!origin) {
    return {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Max-Age": "600",
    };
  }

  const allowed =
    origin === "https://cdn.shopify.com" ||
    /^https:\/\/.*\.myshopify\.com$/.test(origin) ||
    /^https:\/\/.*\.shopify\.com$/.test(origin);

  if (!allowed) {
    return { "Vary": "Origin" };
  }

  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "600",
    "Vary": "Origin",
  };
}

export async function action({ request }: ActionFunctionArgs) {
  const headers = corsHeaders(request);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }

  if (request.method !== "POST") {
    return json({ error: "Method not allowed" }, { status: 405, headers });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return json({ ok: false }, { status: 200, headers });
  }

  const parsed = payloadSchema.safeParse(body);
  if (!parsed.success) {
    // Do not spam storefront with errors; respond 200
    return json({ ok: false }, { status: 200, headers });
  }

  const { token, sessionId, events } = parsed.data;

  const { valid, shopId } = await validatePixelToken(token);
  if (!valid || !shopId) {
    return json({ ok: false }, { status: 200, headers });
  }

  try {
    await processEvents(shopId, sessionId, events);
  } catch (err) {
    console.error("Ingest error", err);
    // Still return 200 to keep storefront safe
    return json({ ok: false }, { status: 200, headers });
  }

  return json({ ok: true }, { status: 200, headers });
}

export async function loader({ request }: LoaderFunctionArgs) {
  const headers = corsHeaders(request);
  return json({ error: "Not found" }, { status: 404, headers });
}
