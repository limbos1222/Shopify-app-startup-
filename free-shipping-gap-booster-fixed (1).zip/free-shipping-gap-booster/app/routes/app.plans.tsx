import type { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useLoaderData, Form } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Button,
  Badge,
  ProgressBar,
  Banner,
} from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { db } from "~/db.server";
import {
  cancelSubscription,
  createSubscription,
  getMonthlySessionCount,
  syncActiveSubscription,
} from "~/lib/billing.server";
import { PLANS, getPlan, type PlanKey } from "~/lib/plans";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);

  // Best-effort sync with Shopify active subscriptions
  await syncActiveSubscription(request).catch(() => null);

  const shop = await db.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Response("Shop not found", { status: 404 });

  const monthlySessionCount = await getMonthlySessionCount(shop.id);
  const plan = getPlan(shop.plan);

  return json({
    currentPlan: shop.plan,
    monthlySessionCount,
    plan,
    subscriptionStatus: shop.subscriptionStatus,
  });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const formData = await request.formData();
  const intent = String(formData.get("intent") ?? "subscribe");

  if (intent === "cancel") {
    await cancelSubscription(request);
    return redirect("/app/plans");
  }

  const planKey = formData.get("plan") as PlanKey;
  if (!PLANS[planKey]) {
    return json({ error: "Invalid plan" }, { status: 400 });
  }

  const confirmationUrl = await createSubscription(request, planKey);
  if (confirmationUrl) return redirect(confirmationUrl);
  return redirect("/app/plans");
};

export default function PlansPage() {
  const { currentPlan, monthlySessionCount, plan, subscriptionStatus } =
    useLoaderData<typeof loader>();

  const usagePct = Math.min(100, Math.round((monthlySessionCount / plan.sessionLimit) * 100));
  const isOver = monthlySessionCount > plan.sessionLimit;

  return (
    <Page title="Plans & Billing" backAction={{ content: "Dashboard", url: "/app" }}>
      <BlockStack gap="500">
        {isOver && (
          <Banner tone="critical">
            You have exceeded your monthly session limit. Upgrade to unlock full analytics.
          </Banner>
        )}

        <Card>
          <BlockStack gap="300">
            <Text as="h2" variant="headingMd">
              Current Usage — {plan.name} Plan
            </Text>
            <ProgressBar progress={usagePct} tone={isOver ? "critical" : "highlight"} />
            <Text as="p" variant="bodyMd" tone="subdued">
              {monthlySessionCount.toLocaleString()} / {plan.sessionLimit.toLocaleString()} sessions this billing month
            </Text>
            <Text as="p" variant="bodySm" tone="subdued">
              Subscription status: {subscriptionStatus}
            </Text>
          </BlockStack>
        </Card>

        {currentPlan !== "free" && (
          <Card>
            <BlockStack gap="200">
              <Text as="h3" variant="headingMd">Cancel Subscription</Text>
              <Form method="post">
                <input type="hidden" name="intent" value="cancel" />
                <Button submit tone="critical">Cancel and downgrade to Free</Button>
              </Form>
            </BlockStack>
          </Card>
        )}

        <Layout>
          {Object.entries(PLANS).map(([key, p]) => {
            const isCurrent = key === currentPlan;
            return (
              <Layout.Section variant="oneQuarter" key={key}>
                <Card>
                  <BlockStack gap="300">
                    <InlineStack align="space-between">
                      <Text as="h3" variant="headingMd">{p.name}</Text>
                      {isCurrent && <Badge tone="success">Current</Badge>}
                    </InlineStack>
                    <Text as="p" variant="headingLg">
                      {p.price === 0 ? "Free" : `$${p.price}/mo`}
                    </Text>
                    <Text as="p" variant="bodyMd" tone="subdued">
                      Up to {p.sessionLimit.toLocaleString()} sessions/month
                    </Text>

                    {!isCurrent && (
                      <Form method="post">
                        <input type="hidden" name="intent" value="subscribe" />
                        <input type="hidden" name="plan" value={key} />
                        <Button submit variant={p.price > plan.price ? "primary" : "secondary"}>
                          {p.price === 0 ? "Downgrade to Free" : p.price > plan.price ? "Upgrade" : "Switch"}
                        </Button>
                      </Form>
                    )}
                  </BlockStack>
                </Card>
              </Layout.Section>
            );
          })}
        </Layout>
      </BlockStack>
    </Page>
  );
}
