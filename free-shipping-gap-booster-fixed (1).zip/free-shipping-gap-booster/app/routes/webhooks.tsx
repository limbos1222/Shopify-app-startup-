import type { ActionFunctionArgs } from "@remix-run/node";
import { authenticate } from "~/shopify.server";
import { db } from "~/db.server";

export const action = async ({ request }: ActionFunctionArgs) => {
  const { topic, shop, session, payload } = await authenticate.webhook(request);

  console.log(`Webhook received: ${topic} for ${shop}`);

  switch (topic) {
    case "APP_UNINSTALLED":
      if (session) {
        await db.shop.delete({ where: { shopDomain: shop } }).catch(() => null);
      }
      break;

    case "CUSTOMERS_DATA_REQUEST":
      console.log(`GDPR data request for ${shop}: no PII stored`, JSON.stringify(payload));
      break;

    case "CUSTOMERS_REDACT":
      console.log(`GDPR customer redact for ${shop}: no PII stored`, JSON.stringify(payload));
      break;

    case "SHOP_REDACT":
      await db.shop.delete({ where: { shopDomain: shop } }).catch(() => null);
      break;

    default:
      console.log(`Unhandled webhook topic: ${topic}`);
  }

  return new Response(null, { status: 200 });
};
