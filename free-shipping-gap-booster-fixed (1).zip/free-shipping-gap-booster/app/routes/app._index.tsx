import type { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useLoaderData, useSubmit } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Select,
  TextField,
  Button,
  Banner,
  Divider,
  Badge,
} from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { db } from "~/db.server";
import { getAggregatedStats } from "~/lib/aggregation.server";
import { getMonthlySessionCount } from "~/lib/billing.server";
import { getPlan } from "~/lib/plans";
import { DashboardHero } from "~/components/DashboardHero";
import { TopProductsTable } from "~/components/TopProductsTable";
import { UpgradeBanner } from "~/components/UpgradeBanner";
import { useState } from "react";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = await db.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Response("Shop not found", { status: 404 });

  const url = new URL(request.url);
  const days = parseInt(url.searchParams.get("days") ?? "7", 10);
  const validDays = [1, 7, 30].includes(days) ? days : 7;

  const stats = await getAggregatedStats(shop.id, validDays);
  const monthlySessionCount = await getMonthlySessionCount(shop.id);
  const plan = getPlan(shop.plan);
  const isLocked = monthlySessionCount > plan.sessionLimit;

  return json({
    shop: {
      id: shop.id,
      shopDomain: shop.shopDomain,
      freeShippingThresholdCents: shop.freeShippingThresholdCents,
      currencyCode: shop.currencyCode,
      plan: shop.plan,
    },
    stats,
    monthlySessionCount,
    plan,
    isLocked,
    days: validDays,
  });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const formData = await request.formData();
  const thresholdRaw = formData.get("threshold");
  const threshold = parseFloat(String(thresholdRaw));
  if (isNaN(threshold) || threshold < 0) {
    return json({ error: "Invalid threshold" }, { status: 400 });
  }
  await db.shop.update({
    where: { shopDomain: session.shop },
    data: { freeShippingThresholdCents: Math.round(threshold * 100) },
  });
  return redirect("/app");
};

export default function Dashboard() {
  const { shop, stats, plan, isLocked, days, monthlySessionCount } =
    useLoaderData<typeof loader>();
  const submit = useSubmit();
  const [selectedDays, setSelectedDays] = useState(String(days));
  const [thresholdInput, setThresholdInput] = useState(
    String(shop.freeShippingThresholdCents / 100)
  );

  const currency = shop.currencyCode;

  const handleDaysChange = (value: string) => {
    setSelectedDays(value);
    const url = new URL(window.location.href);
    url.searchParams.set("days", value);
    window.location.href = url.toString();
  };

  const handleThresholdSave = () => {
    submit({ threshold: thresholdInput }, { method: "post" });
  };

  const pct = ((monthlySessionCount / plan.sessionLimit) * 100).toFixed(0);

  return (
    <Page title="Free Shipping Gap Booster" subtitle="Analytics & Recommendations">
      <BlockStack gap="500">
        {isLocked && (
          <UpgradeBanner
            currentPlan={shop.plan}
            sessionCount={monthlySessionCount}
            sessionLimit={plan.sessionLimit}
          />
        )}

        <Layout>
          <Layout.Section>
            <BlockStack gap="400">
              <Card>
                <InlineStack align="end">
                  <Select
                    label="Time range"
                    options={[
                      { label: "Last 24 hours", value: "1" },
                      { label: "Last 7 days", value: "7" },
                      { label: "Last 30 days", value: "30" },
                    ]}
                    value={selectedDays}
                    onChange={handleDaysChange}
                  />
                </InlineStack>
              </Card>

              <DashboardHero
                nearThresholdRate={stats.nearThresholdRate}
                avgGapCents={stats.avgGapCents}
                estMonthlyUpliftCents={stats.estMonthlyUpliftCents}
                cartSessions={stats.cartSessions}
                nearThresholdSessions={stats.nearThresholdSessions}
                currency={currency}
              />

              <Card>
                <BlockStack gap="300">
                  <Text as="h2" variant="headingMd">
                    Top Products in Near-Threshold Carts
                  </Text>
                  <Text as="p" variant="bodyMd" tone="subdued">
                    Products most frequently added in sessions within $1–$15 of your free shipping threshold.
                  </Text>
                  {isLocked ? (
                    <Banner tone="warning">
                      Upgrade your plan to unlock product-level analytics.
                    </Banner>
                  ) : (
                    <TopProductsTable products={stats.topProducts} currency={currency} />
                  )}
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>

          <Layout.Section variant="oneThird">
            <BlockStack gap="400">
              <Card>
                <BlockStack gap="300">
                  <Text as="h2" variant="headingMd">
                    Free Shipping Threshold
                  </Text>
                  <TextField
                    label={`Threshold (${currency})`}
                    type="number"
                    value={thresholdInput}
                    onChange={setThresholdInput}
                    prefix={currency === "USD" ? "$" : ""}
                    autoComplete="off"
                    helpText="The minimum cart value for free shipping in your store."
                  />
                  <Button onClick={handleThresholdSave} variant="primary">
                    Save Threshold
                  </Button>
                </BlockStack>
              </Card>

              <Card>
                <BlockStack gap="300">
                  <Text as="h2" variant="headingMd">
                    Plan Usage
                  </Text>
                  <InlineStack align="space-between">
                    <Text as="p" variant="bodyMd">
                      {plan.name} Plan
                    </Text>
                    <Badge tone={isLocked ? "critical" : "success"}>{pct}% used</Badge>
                  </InlineStack>
                  <Text as="p" variant="bodyMd" tone="subdued">
                    {monthlySessionCount.toLocaleString()} / {plan.sessionLimit.toLocaleString()} sessions this month
                  </Text>
                  <Button url="/app/plans" variant="plain">
                    Manage Plan →
                  </Button>
                </BlockStack>
              </Card>

              <Card>
                <BlockStack gap="300">
                  <Text as="h2" variant="headingMd">
                    Recommended Next Actions
                  </Text>
                  <Divider />
                  <BlockStack gap="200">
                    <Text as="p" variant="bodyMd">
                      💡 <strong>Set threshold</strong> to match your Shopify shipping rule exactly so gap calculations are accurate.
                    </Text>
                    <Divider />
                    <Text as="p" variant="bodyMd">
                      💡 <strong>Merchandising idea</strong>: add low-cost complements (accessories, add-ons) to encourage customers to cross the threshold naturally.
                    </Text>
                    <Divider />
                    <Text as="p" variant="bodyMd">
                      💡 <strong>Test threshold</strong>: if your avg gap is &gt; $10, try lowering the free shipping threshold by $5–$10.
                    </Text>
                  </BlockStack>
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>

        <Card>
          <BlockStack gap="200">
            <Text as="p" variant="bodySm" tone="subdued">
              Note: Daily aggregates are computed by the rollup job. During development, run <code>npm run daily-rollup</code> to populate the dashboard.
            </Text>
          </BlockStack>
        </Card>
      </BlockStack>
    </Page>
  );
}
