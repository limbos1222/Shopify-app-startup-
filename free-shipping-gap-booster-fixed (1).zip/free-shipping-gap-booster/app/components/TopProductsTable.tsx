import { DataTable, Text, BlockStack } from "@shopify/polaris";

interface Props {
  products: { productId: string; count: number }[];
  currency: string;
}

export function TopProductsTable({ products }: Props) {
  if (products.length === 0) {
    return (
      <Text as="p" variant="bodyMd" tone="subdued">
        No near-threshold sessions recorded yet.
      </Text>
    );
  }

  const rows = products.map((p, i) => [
    `#${i + 1}`,
    p.productId,
    p.count.toLocaleString(),
  ]);

  return (
    <BlockStack gap="200">
      <DataTable
        columnContentTypes={["text", "text", "numeric"]}
        headings={["Rank", "Product ID", "Near-Threshold Sessions"]}
        rows={rows}
      />
      <Text as="p" variant="bodySm" tone="subdued">
        Product IDs shown. Cross-reference in your Shopify Products admin.
        Product names are not fetched to minimize API calls.
      </Text>
    </BlockStack>
  );
}
