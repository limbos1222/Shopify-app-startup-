import { Card, Text, BlockStack, InlineGrid, Divider } from "@shopify/polaris";

interface Props {
  nearThresholdRate: number;
  avgGapCents: number;
  estMonthlyUpliftCents: number;
  cartSessions: number;
  nearThresholdSessions: number;
  currency: string;
}

function fmt(cents: number, currency: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(cents / 100);
}

export function DashboardHero({
  nearThresholdRate,
  avgGapCents,
  estMonthlyUpliftCents,
  cartSessions,
  nearThresholdSessions,
  currency,
}: Props) {
  const pctStr = (nearThresholdRate * 100).toFixed(1) + "%";

  return (
    <Card>
      <BlockStack gap="400">
        <Text as="h2" variant="headingLg">
          Free Shipping Gap Summary
        </Text>
        <Divider />
        <InlineGrid columns={3} gap="400">
          <BlockStack gap="100">
            <Text as="p" variant="headingXl" fontWeight="bold">
              {pctStr}
            </Text>
            <Text as="p" variant="bodyMd" tone="subdued">
              of cart sessions stopped within $1–$15 of free shipping
            </Text>
            <Text as="p" variant="bodySm" tone="subdued">
              {nearThresholdSessions.toLocaleString()} of{" "}
              {cartSessions.toLocaleString()} sessions
            </Text>
          </BlockStack>

          <BlockStack gap="100">
            <Text as="p" variant="headingXl" fontWeight="bold">
              {fmt(avgGapCents, currency)}
            </Text>
            <Text as="p" variant="bodyMd" tone="subdued">
              average gap below threshold
            </Text>
          </BlockStack>

          <BlockStack gap="100">
            <Text as="p" variant="headingXl" fontWeight="bold" tone="success">
              {fmt(estMonthlyUpliftCents, currency)}
            </Text>
            <Text as="p" variant="bodyMd" tone="subdued">
              estimated additional revenue opportunity / month
            </Text>
            <Text as="p" variant="bodySm" tone="subdued">
              Based on 35% uplift factor — see Details for methodology
            </Text>
          </BlockStack>
        </InlineGrid>
      </BlockStack>
    </Card>
  );
}
