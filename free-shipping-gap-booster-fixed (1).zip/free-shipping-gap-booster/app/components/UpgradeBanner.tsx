import { Banner } from "@shopify/polaris";

interface Props {
  currentPlan: string;
  sessionCount: number;
  sessionLimit: number;
}

export function UpgradeBanner({ currentPlan, sessionCount, sessionLimit }: Props) {
  return (
    <Banner
      title="Session limit reached"
      tone="warning"
      action={{ content: "Upgrade Plan", url: "/app/plans" }}
    >
      You have used {sessionCount.toLocaleString()} of your {sessionLimit.toLocaleString()} monthly sessions on the {currentPlan} plan.
      Upgrade to unlock full analytics and higher limits.
    </Banner>
  );
}
