import { db } from "~/db.server";

const UPLIFT_FACTOR = 0.35;
const NEAR_THRESHOLD_MIN_CENTS = 100; // $1
const NEAR_THRESHOLD_MAX_CENTS = 1500; // $15

export async function recomputeDailyAgg(shopId: string, date: Date): Promise<void> {
  const shop = await db.shop.findUnique({ where: { id: shopId } });
  if (!shop) return;

  const threshold = shop.freeShippingThresholdCents;
  const dayStart = new Date(date);
  dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(date);
  dayEnd.setHours(23, 59, 59, 999);

  const sessions = await db.sessionCartAgg.findMany({
    where: { shopId, date: { gte: dayStart, lte: dayEnd } },
  });

  const cartSessions = sessions.filter((s) => s.addEventsCount > 0).length;

  const nearThresholdSessions = sessions.filter((s) => {
    if (s.purchased) return false;
    if (s.addEventsCount === 0) return false;
    const gap = threshold - s.maxCartValueCents;
    return gap >= NEAR_THRESHOLD_MIN_CENTS && gap <= NEAR_THRESHOLD_MAX_CENTS;
  });

  const nearCount = nearThresholdSessions.length;
  const avgGapCents =
    nearCount > 0
      ? Math.round(
          nearThresholdSessions.reduce((sum, s) => sum + (threshold - s.maxCartValueCents), 0) /
            nearCount
        )
      : 0;

  const estUpliftCents = Math.round(nearCount * avgGapCents * UPLIFT_FACTOR);

  const productCounts: Record<string, number> = {};
  for (const s of nearThresholdSessions) {
    if (s.topProductId) {
      productCounts[s.topProductId] = (productCounts[s.topProductId] ?? 0) + 1;
    }
  }
  const topProducts = Object.entries(productCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([productId, count]) => ({ productId, count }));

  await db.dailyGapAgg.upsert({
    where: { shopId_date: { shopId, date: dayStart } },
    create: {
      shopId,
      date: dayStart,
      cartSessions,
      nearThresholdSessions: nearCount,
      avgGapCents,
      estUpliftCents,
      topProductsJson: JSON.stringify(topProducts),
    },
    update: {
      cartSessions,
      nearThresholdSessions: nearCount,
      avgGapCents,
      estUpliftCents,
      topProductsJson: JSON.stringify(topProducts),
    },
  });
}

export async function getAggregatedStats(shopId: string, days: number) {
  const since = new Date();
  since.setDate(since.getDate() - days);
  since.setHours(0, 0, 0, 0);

  const rows = await db.dailyGapAgg.findMany({
    where: { shopId, date: { gte: since } },
    orderBy: { date: "desc" },
  });

  const totalCart = rows.reduce((s, r) => s + r.cartSessions, 0);
  const totalNear = rows.reduce((s, r) => s + r.nearThresholdSessions, 0);
  const nearThresholdRate = totalCart > 0 ? totalNear / totalCart : 0;

  const avgGapCents =
    totalNear > 0
      ? Math.round(
          rows.reduce((s, r) => s + r.avgGapCents * r.nearThresholdSessions, 0) / totalNear
        )
      : 0;

  const dailyUplift =
    rows.length > 0 ? rows.reduce((s, r) => s + r.estUpliftCents, 0) / rows.length : 0;
  const estMonthlyUpliftCents = Math.round(dailyUplift * 30);

  const productCounts: Record<string, number> = {};
  for (const row of rows) {
    const products = JSON.parse(row.topProductsJson) as { productId: string; count: number }[];
    for (const p of products) {
      productCounts[p.productId] = (productCounts[p.productId] ?? 0) + p.count;
    }
  }
  const topProducts = Object.entries(productCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([productId, count]) => ({ productId, count }));

  return {
    nearThresholdRate,
    avgGapCents,
    estMonthlyUpliftCents,
    cartSessions: totalCart,
    nearThresholdSessions: totalNear,
    topProducts,
    dailyRows: rows.map((r) => ({
      date: r.date,
      cartSessions: r.cartSessions,
      nearThresholdSessions: r.nearThresholdSessions,
      avgGapCents: r.avgGapCents,
      estUpliftCents: r.estUpliftCents,
    })),
  };
}
