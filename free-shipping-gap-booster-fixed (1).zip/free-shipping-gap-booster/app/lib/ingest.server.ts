import { createHash } from "node:crypto";
import { db } from "~/db.server";
import { incrementMonthlySession } from "~/lib/billing.server";

export function hashSession(sessionId: string): string {
  return createHash("sha256").update(sessionId).digest("hex");
}

export interface IncomingEvent {
  type: "add_to_cart" | "remove_from_cart" | "checkout_started" | "purchase" | string;
  productId?: string;
  variantId?: string;
  qty: number;
  priceCents: number;
  ts: number;
  path?: string;
}

export async function processEvents(shopId: string, sessionId: string, events: IncomingEvent[]): Promise<void> {
  const sessionHash = hashSession(sessionId);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  await db.eventRaw.createMany({
    data: events.map((e) => ({
      shopId,
      sessionHash,
      type: e.type,
      ts: new Date(e.ts),
      payloadJson: JSON.stringify({
        productId: e.productId,
        variantId: e.variantId,
        qty: e.qty,
        priceCents: e.priceCents,
        path: e.path,
      }),
    })),
  });

  let cartDelta = 0;
  let hasPurchase = false;
  let addCount = 0;
  let removeCount = 0;
  let topProductId: string | null = null;

  for (const e of events) {
    if (e.type === "add_to_cart") {
      cartDelta += e.priceCents * e.qty;
      addCount++;
      topProductId = e.productId ?? topProductId;
    } else if (e.type === "remove_from_cart") {
      cartDelta -= e.priceCents * e.qty;
      removeCount++;
    } else if (e.type === "purchase" || e.type === "checkout_completed") {
      hasPurchase = true;
    }
  }

  const existing = await db.sessionCartAgg.findUnique({
    where: {
      shopId_sessionHash_date: { shopId, sessionHash, date: today },
    },
  });

  const newLastValue = Math.max(0, (existing?.lastCartValueCents ?? 0) + cartDelta);
  const newMax = Math.max(existing?.maxCartValueCents ?? 0, newLastValue);

  await db.sessionCartAgg.upsert({
    where: {
      shopId_sessionHash_date: { shopId, sessionHash, date: today },
    },
    create: {
      shopId,
      sessionHash,
      date: today,
      lastCartValueCents: newLastValue,
      maxCartValueCents: newMax,
      addEventsCount: addCount,
      removeEventsCount: removeCount,
      topProductId: topProductId,
      purchased: hasPurchase,
    },
    update: {
      lastCartValueCents: newLastValue,
      maxCartValueCents: newMax,
      addEventsCount: { increment: addCount },
      removeEventsCount: { increment: removeCount },
      topProductId: topProductId ?? undefined,
      purchased: hasPurchase ? true : undefined,
    },
  });

  if (addCount > 0) {
    await incrementMonthlySession(shopId, sessionHash);
  }
}
