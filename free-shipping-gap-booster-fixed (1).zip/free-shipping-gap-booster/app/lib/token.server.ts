import { createHash, randomBytes } from "node:crypto";
import { db } from "~/db.server";

const TOKEN_TTL_MS = 10 * 60 * 1000;

export function hashToken(raw: string): string {
  return createHash("sha256").update(raw).digest("hex");
}

export async function issuePixelToken(shopId: string): Promise<string> {
  const raw = randomBytes(32).toString("hex");
  const tokenHash = hashToken(raw);
  const expiresAt = new Date(Date.now() + TOKEN_TTL_MS);
  await db.pixelToken.create({ data: { shopId, tokenHash, expiresAt } });
  return raw;
}

export async function validatePixelToken(rawToken: string): Promise<{ valid: boolean; shopId: string | null }> {
  const tokenHash = hashToken(rawToken);
  const record = await db.pixelToken.findUnique({ where: { tokenHash } });
  if (!record) return { valid: false, shopId: null };

  if (record.expiresAt < new Date()) {
    await db.pixelToken.delete({ where: { tokenHash } }).catch(() => null);
    return { valid: false, shopId: null };
  }

  return { valid: true, shopId: record.shopId };
}
