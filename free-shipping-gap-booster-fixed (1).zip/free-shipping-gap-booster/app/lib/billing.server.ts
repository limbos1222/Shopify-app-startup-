import { db } from "~/db.server";
import { authenticate } from "~/shopify.server";
import { PLANS, type PlanKey } from "~/lib/plans";

function isTestCharge(): boolean {
  // In dev + staging keep charges in test mode
  if (process.env.SHOPIFY_BILLING_TEST === "1") return true;
  return process.env.NODE_ENV !== "production";
}

export async function createSubscription(request: Request, planKey: PlanKey): Promise<string> {
  const { admin, session } = await authenticate.admin(request);
  const plan = PLANS[planKey];

  if (!plan || planKey === "free" || plan.price === 0) {
    await db.shop.update({
      where: { shopDomain: session.shop },
      data: {
        plan: "free",
        subscriptionGid: null,
        subscriptionStatus: "NONE",
      },
    });
    return "";
  }

  const returnUrl = `${process.env.SHOPIFY_APP_URL}/app/plans`;
  const mutation = `#graphql
    mutation CreateSubscription($name: String!, $returnUrl: URL!, $test: Boolean!, $price: MoneyInput!) {
      appSubscriptionCreate(
        name: $name
        returnUrl: $returnUrl
        test: $test
        lineItems: [
          {
            plan: {
              appRecurringPricingDetails: {
                price: $price
                interval: EVERY_30_DAYS
              }
            }
          }
        ]
      ) {
        confirmationUrl
        appSubscription {
          id
          status
          name
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const resp = await admin.graphql(mutation, {
    variables: {
      name: `${plan.name} Plan`,
      returnUrl,
      test: isTestCharge(),
      price: {
        amount: plan.price,
        currencyCode: "USD",
      },
    },
  });

  const json = (await resp.json()) as any;
  const err = json?.data?.appSubscriptionCreate?.userErrors?.[0]?.message;
  if (err) throw new Error(err);

  const subscription = json?.data?.appSubscriptionCreate?.appSubscription;
  const confirmationUrl = json?.data?.appSubscriptionCreate?.confirmationUrl as string | undefined;

  if (subscription?.id) {
    await db.shop.update({
      where: { shopDomain: session.shop },
      data: {
        subscriptionGid: subscription.id,
        subscriptionStatus: subscription.status ?? "PENDING",
        plan: planKey,
      },
    });
  }

  return confirmationUrl ?? "";
}

export async function syncActiveSubscription(request: Request): Promise<void> {
  const { admin, session } = await authenticate.admin(request);

  const query = `#graphql
    query ActiveSubs {
      currentAppInstallation {
        activeSubscriptions {
          id
          name
          status
        }
      }
    }
  `;

  const resp = await admin.graphql(query);
  const json = (await resp.json()) as any;
  const subs: Array<{ id: string; name: string; status: string }> =
    json?.data?.currentAppInstallation?.activeSubscriptions ?? [];

  // If multiple, prefer ACTIVE
  const active = subs.find((s) => s.status === "ACTIVE") ?? subs[0];

  let resolvedPlan: PlanKey = "free";
  if (active?.name) {
    const n = active.name.toLowerCase();
    if (n.includes("starter")) resolvedPlan = "starter";
    else if (n.includes("growth")) resolvedPlan = "growth";
    else if (n.includes("pro")) resolvedPlan = "pro";
  }

  await db.shop.update({
    where: { shopDomain: session.shop },
    data: {
      plan: resolvedPlan,
      subscriptionGid: active?.id ?? null,
      subscriptionStatus: active?.status ?? "NONE",
    },
  });
}

export async function cancelSubscription(request: Request): Promise<void> {
  const { admin, session } = await authenticate.admin(request);
  const shop = await db.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop?.subscriptionGid) return;

  const mutation = `#graphql
    mutation Cancel($id: ID!) {
      appSubscriptionCancel(id: $id, prorate: true) {
        appSubscription {
          id
          status
        }
        userErrors {
          message
        }
      }
    }
  `;

  const resp = await admin.graphql(mutation, { variables: { id: shop.subscriptionGid } });
  const json = (await resp.json()) as any;
  const err = json?.data?.appSubscriptionCancel?.userErrors?.[0]?.message;
  if (err) throw new Error(err);

  await db.shop.update({
    where: { shopDomain: session.shop },
    data: {
      plan: "free",
      subscriptionStatus: json?.data?.appSubscriptionCancel?.appSubscription?.status ?? "CANCELLED",
      subscriptionGid: null,
    },
  });
}

export function getMonthKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export async function getMonthlySessionCount(shopId: string): Promise<number> {
  const monthKey = getMonthKey(new Date());
  return db.monthlySession.count({ where: { shopId, monthKey } });
}

export async function incrementMonthlySession(shopId: string, sessionHash: string): Promise<boolean> {
  const monthKey = getMonthKey(new Date());
  try {
    await db.monthlySession.create({ data: { shopId, monthKey, sessionHash } });
    return true;
  } catch {
    return false;
  }
}
