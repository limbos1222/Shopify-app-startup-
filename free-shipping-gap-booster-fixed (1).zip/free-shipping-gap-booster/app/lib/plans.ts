export const PLANS = {
  free: {
    key: "free",
    name: "Free",
    price: 0,
    sessionLimit: 200,
  },
  starter: {
    key: "starter",
    name: "Starter",
    price: 7,
    sessionLimit: 5_000,
  },
  growth: {
    key: "growth",
    name: "Growth",
    price: 19,
    sessionLimit: 25_000,
  },
  pro: {
    key: "pro",
    name: "Pro",
    price: 39,
    sessionLimit: 100_000,
  },
} as const;

export type PlanKey = keyof typeof PLANS;

export function getPlan(key: string): (typeof PLANS)[PlanKey] {
  const k = (key as PlanKey) || "free";
  return PLANS[k] ?? PLANS.free;
}
