import "@shopify/shopify-app-remix/adapters/node";
import {
  AppDistribution,
  DeliveryMethod,
  LATEST_API_VERSION,
  shopifyApp,
} from "@shopify/shopify-app-remix/server";
import { PrismaSessionStorage } from "@shopify/shopify-app-session-storage-prisma";
import { randomUUID } from "node:crypto";
import { db } from "~/db.server";

const shopify = shopifyApp({
  apiKey: process.env.SHOPIFY_API_KEY!,
  apiSecretKey: process.env.SHOPIFY_API_SECRET!,
  apiVersion: LATEST_API_VERSION,
  scopes: process.env.SCOPES?.split(","),
  appUrl: process.env.SHOPIFY_APP_URL!,
  authPathPrefix: "/auth",
  sessionStorage: new PrismaSessionStorage(db),
  distribution: AppDistribution.AppStore,
  webhooks: {
    APP_UNINSTALLED: {
      deliveryMethod: DeliveryMethod.Http,
      callbackUrl: "/webhooks",
    },
    CUSTOMERS_DATA_REQUEST: {
      deliveryMethod: DeliveryMethod.Http,
      callbackUrl: "/webhooks",
    },
    CUSTOMERS_REDACT: {
      deliveryMethod: DeliveryMethod.Http,
      callbackUrl: "/webhooks",
    },
    SHOP_REDACT: {
      deliveryMethod: DeliveryMethod.Http,
      callbackUrl: "/webhooks",
    },
  },
  hooks: {
    afterAuth: async ({ session }) => {
      shopify.registerWebhooks({ session });

      await db.shop.upsert({
        where: { shopDomain: session.shop },
        create: {
          shopDomain: session.shop,
          accessToken: session.accessToken!,
          pixelInstanceId: randomUUID(),
        },
        update: {
          accessToken: session.accessToken!,
        },
      });

      await ensureWebPixel(session.shop, session.accessToken!);
    },
  },
  future: {
    unstable_newEmbeddedAuthStrategy: true,
  },
});

export default shopify;
export const apiVersion = LATEST_API_VERSION;
export const addDocumentResponseHeaders = shopify.addDocumentResponseHeaders;
export const authenticate = shopify.authenticate;
export const unauthenticated = shopify.unauthenticated;
export const login = shopify.login;
export const sessionStorage = shopify.sessionStorage;

// ---------------------------------------------------------------------------
// Web Pixel registration / update
// ---------------------------------------------------------------------------
async function ensureWebPixel(shopDomain: string, accessToken: string) {
  const shop = await db.shop.findUnique({ where: { shopDomain } });
  if (!shop) return;

  const settingsObj = {
    shopDomain,
    pixelInstanceId: shop.pixelInstanceId,
    appUrl: process.env.SHOPIFY_APP_URL,
  };

  // Shopify expects settings as a STRING (JSON) for web pixel settings
  const settings = JSON.stringify(settingsObj);

  const query = shop.webPixelId
    ? `mutation UpdatePixel($id: ID!, $settings: String!) {
        webPixelUpdate(id: $id, webPixel: { settings: $settings }) {
          webPixel { id }
          userErrors { message }
        }
      }`
    : `mutation CreatePixel($settings: String!) {
        webPixelCreate(webPixel: { settings: $settings }) {
          webPixel { id }
          userErrors { message }
        }
      }`;

  const variables = shop.webPixelId
    ? { id: shop.webPixelId, settings }
    : { settings };

  try {
    const res = await fetch(
      `https://${shopDomain}/admin/api/${LATEST_API_VERSION}/graphql.json`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Shopify-Access-Token": accessToken,
        },
        body: JSON.stringify({ query, variables }),
      }
    );

    const json = (await res.json()) as any;
    const pixel =
      json?.data?.webPixelCreate?.webPixel ||
      json?.data?.webPixelUpdate?.webPixel;

    const errors =
      json?.data?.webPixelCreate?.userErrors ||
      json?.data?.webPixelUpdate?.userErrors;

    if (errors?.length) {
      console.error("Web Pixel userErrors:", errors);
      return;
    }

    if (pixel?.id && !shop.webPixelId) {
      await db.shop.update({
        where: { shopDomain },
        data: { webPixelId: pixel.id },
      });
    }
  } catch (e) {
    console.error("Web pixel registration failed", e);
  }
}
