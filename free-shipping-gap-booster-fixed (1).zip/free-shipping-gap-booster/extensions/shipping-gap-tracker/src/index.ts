import { register } from "@shopify/web-pixels-extension";

register(async ({ settings, analytics, browser }) => {
  // Settings may arrive as an object or a JSON string.
  const s: any =
    typeof settings === "string"
      ? (() => {
          try {
            return JSON.parse(settings);
          } catch {
            return {};
          }
        })()
      : (settings as any) ?? {};

  const shopDomain = String(s.shopDomain || "");
  const pixelInstanceId = String(s.pixelInstanceId || "");
  const appUrl = String(s.appUrl || "");

  if (!shopDomain || !pixelInstanceId || !appUrl) return;

  // Session ID (anonymous)
  const SESSION_KEY = "__fsgb_sid";
  let sessionId: string = browser.sessionStorage.getItem(SESSION_KEY) ?? "";
  if (!sessionId) {
    sessionId = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
    browser.sessionStorage.setItem(SESSION_KEY, sessionId);
  }

  // Use Shopify-provided request helper when available (preferred in Web Pixel context).
  type HttpResult = { status: number; body: string | null };

  async function httpRequest(url: string, init: { method: string; headers?: Record<string, string>; body?: string }): Promise<HttpResult> {
    try {
      const anyBrowser: any = browser as any;
      if (typeof anyBrowser.sendHttpRequest === "function") {
        const r = await anyBrowser.sendHttpRequest(url, {
          method: init.method,
          headers: init.headers ?? {},
          body: init.body ?? "",
        });
        return { status: Number(r.status ?? 0), body: typeof r.body === "string" ? r.body : r.body ? JSON.stringify(r.body) : null };
      }
      // Fallback: use fetch if available.
      const res = await (globalThis as any).fetch(url, {
        method: init.method,
        headers: init.headers,
        body: init.body,
        keepalive: true,
      });
      const body = await res.text();
      return { status: res.status, body };
    } catch {
      return { status: 0, body: null };
    }
  }

  function okStatus(status: number) {
    return status >= 200 && status < 300;
  }

  // Token management
  let currentToken: string | null = null;
  let tokenExpiresAt = 0;
  let tokenFetchInFlight: Promise<string | null> | null = null;

  async function fetchToken(): Promise<string | null> {
    try {
      const res = await httpRequest(`${appUrl}/api/pixel-token`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shopDomain, pixelInstanceId }),
      });
      if (!okStatus(res.status) || !res.body) return null;
      let json: any = {};
      try {
        json = JSON.parse(res.body);
      } catch {
        json = {};
      }
      return typeof json.token === "string" ? json.token : null;
    } catch {
      return null;
    }
  }

  async function getToken(): Promise<string | null> {
    const now = Date.now();
    if (currentToken && now < tokenExpiresAt - 30_000) return currentToken;

    if (!tokenFetchInFlight) {
      tokenFetchInFlight = fetchToken().finally(() => {
        tokenFetchInFlight = null;
      });
    }

    const t = await tokenFetchInFlight;
    if (t) {
      currentToken = t;
      tokenExpiresAt = now + 10 * 60 * 1000;
    }
    return currentToken;
  }

  // Queue & batching
  interface QueuedEvent {
    type: string;
    productId?: string;
    variantId?: string;
    qty: number;
    priceCents: number;
    ts: number;
    path?: string;
  }

  const queue: QueuedEvent[] = [];
  const MAX_QUEUE = 300;
  let flushTimer: ReturnType<typeof setTimeout> | null = null;
  let retryTimer: ReturnType<typeof setTimeout> | null = null;

  function enqueue(evt: QueuedEvent) {
    if (queue.length >= MAX_QUEUE) {
      queue.shift();
    }
    queue.push(evt);
    scheduleFlush();
  }

  async function flush(): Promise<void> {
    if (queue.length === 0) return;

    const token = await getToken();
    if (!token) {
      // Retry later without dropping events
      if (!retryTimer) {
        retryTimer = setTimeout(() => {
          retryTimer = null;
          flush();
        }, 10_000);
      }
      return;
    }

    const batch = queue.splice(0, queue.length);

    try {
      await doFetch(`${appUrl}/api/ingest`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, sessionId, events: batch }),
        keepalive: true,
      });
    } catch {
      // Put events back (best-effort)
      for (const e of batch) {
        if (queue.length >= MAX_QUEUE) queue.shift();
        queue.unshift(e);
      }
      if (!retryTimer) {
        retryTimer = setTimeout(() => {
          retryTimer = null;
          flush();
        }, 10_000);
      }
    }
  }

  function scheduleFlush(): void {
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
      flushTimer = null;
      flush();
    }, 5_000);
  }

  browser.addEventListener("visibilitychange", () => {
    if (browser.document.visibilityState === "hidden") {
      flush();
    }
  });

  function toCents(amount: number | string | undefined): number {
    if (amount === undefined || amount === null) return 0;
    return Math.round(Number(amount) * 100);
  }

  analytics.subscribe("product_added_to_cart", (event) => {
    const cartLine = (event as any).data?.cartLine;
    const merchandise = cartLine?.merchandise;
    enqueue({
      type: "add_to_cart",
      productId: merchandise?.product?.id,
      variantId: merchandise?.id,
      qty: cartLine?.quantity ?? 1,
      priceCents: toCents(merchandise?.price?.amount),
      ts: Date.now(),
      path: browser.location?.pathname,
    });
  });

  analytics.subscribe("product_removed_from_cart", (event) => {
    const cartLine = (event as any).data?.cartLine;
    const merchandise = cartLine?.merchandise;
    enqueue({
      type: "remove_from_cart",
      productId: merchandise?.product?.id,
      variantId: merchandise?.id,
      qty: cartLine?.quantity ?? 1,
      priceCents: toCents(merchandise?.price?.amount),
      ts: Date.now(),
      path: browser.location?.pathname,
    });
  });

  analytics.subscribe("checkout_started", (event) => {
    enqueue({
      type: "checkout_started",
      qty: 1,
      priceCents: toCents((event as any).data?.checkout?.totalPrice?.amount),
      ts: Date.now(),
    });
  });

  analytics.subscribe("checkout_completed", (event) => {
    enqueue({
      type: "purchase",
      qty: 1,
      priceCents: toCents((event as any).data?.checkout?.totalPrice?.amount),
      ts: Date.now(),
    });
    flush();
  });
});
