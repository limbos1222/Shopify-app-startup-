# Privacy Policy — Free Shipping Gap Booster

**Last updated:** 2026-02-25

## Data we collect

Free Shipping Gap Booster collects **no personally identifiable information (PII)**.

Via our Web Pixel extension, we collect anonymous behavioral events:
- Anonymous session UUID (generated per browser session and stored in sessionStorage). The UUID is **SHA-256 hashed** before storage.
- Product and variant IDs for add/remove events
- Quantity, price (cents), timestamp, and page path

## Data retention

See `DATA_RETENTION.md`.

## Uninstall / deletion

On uninstall (`app/uninstalled`) or `shop/redact`, all shop data is deleted via cascade.
