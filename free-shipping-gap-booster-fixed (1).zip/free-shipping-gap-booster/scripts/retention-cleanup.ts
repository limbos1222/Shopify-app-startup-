#!/usr/bin/env tsx
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function run() {
  const now = new Date();

  const eventRawCutoff = new Date(now);
  eventRawCutoff.setDate(eventRawCutoff.getDate() - 30);
  const deletedRaw = await db.eventRaw.deleteMany({ where: { createdAt: { lt: eventRawCutoff } } });
  console.log(`Deleted ${deletedRaw.count} old EventRaw rows.`);

  const deletedTokens = await db.pixelToken.deleteMany({ where: { expiresAt: { lt: now } } });
  console.log(`Deleted ${deletedTokens.count} expired PixelTokens.`);

  const monthlySessionCutoff = new Date(now);
  monthlySessionCutoff.setMonth(monthlySessionCutoff.getMonth() - 13);
  const cutoffKey = `${monthlySessionCutoff.getFullYear()}-${String(monthlySessionCutoff.getMonth() + 1).padStart(2, "0")}`;
  const deletedMS = await db.monthlySession.deleteMany({ where: { monthKey: { lt: cutoffKey } } });
  console.log(`Deleted ${deletedMS.count} old MonthlySessions.`);

  const dailyAggCutoff = new Date(now);
  dailyAggCutoff.setMonth(dailyAggCutoff.getMonth() - 13);
  const deletedAgg = await db.dailyGapAgg.deleteMany({ where: { date: { lt: dailyAggCutoff } } });
  console.log(`Deleted ${deletedAgg.count} old DailyGapAgg rows.`);

  const sessionCutoff = new Date(now);
  sessionCutoff.setDate(sessionCutoff.getDate() - 30);
  const deletedSessions = await db.sessionCartAgg.deleteMany({ where: { date: { lt: sessionCutoff } } });
  console.log(`Deleted ${deletedSessions.count} old SessionCartAgg rows.`);

  await db.$disconnect();
  console.log("Retention cleanup complete.");
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
