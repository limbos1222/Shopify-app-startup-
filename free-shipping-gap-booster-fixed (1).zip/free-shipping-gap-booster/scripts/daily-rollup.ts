#!/usr/bin/env tsx
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const NEAR_MIN = 100;
const NEAR_MAX = 1500;
const UPLIFT_FACTOR = 0.35;

async function rollupShopDay(shopId: string, date: Date) {
  const shop = await db.shop.findUnique({ where: { id: shopId } });
  if (!shop) return;

  const threshold = shop.freeShippingThresholdCents;
  const dayStart = new Date(date);
  dayStart.setHours(0, 0, 0, 0);
  const dayEnd = new Date(date);
  dayEnd.setHours(23, 59, 59, 999);

  const sessions = await db.sessionCartAgg.findMany({
    where: { shopId, date: { gte: dayStart, lte: dayEnd } },
  });

  const cartSessions = sessions.filter((s) => s.addEventsCount > 0).length;
  const nearSessions = sessions.filter((s) => {
    if (s.purchased || s.addEventsCount === 0) return false;
    const gap = threshold - s.maxCartValueCents;
    return gap >= NEAR_MIN && gap <= NEAR_MAX;
  });

  const nearCount = nearSessions.length;
  const avgGapCents =
    nearCount > 0
      ? Math.round(
          nearSessions.reduce((sum, s) => sum + (threshold - s.maxCartValueCents), 0) / nearCount
        )
      : 0;

  const estUpliftCents = Math.round(nearCount * avgGapCents * UPLIFT_FACTOR);

  const productCounts: Record<string, number> = {};
  for (const s of nearSessions) {
    if (s.topProductId) {
      productCounts[s.topProductId] = (productCounts[s.topProductId] ?? 0) + 1;
    }
  }

  const topProducts = Object.entries(productCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([productId, count]) => ({ productId, count }));

  await db.dailyGapAgg.upsert({
    where: { shopId_date: { shopId, date: dayStart } },
    create: {
      shopId,
      date: dayStart,
      cartSessions,
      nearThresholdSessions: nearCount,
      avgGapCents,
      estUpliftCents,
      topProductsJson: JSON.stringify(topProducts),
    },
    update: {
      cartSessions,
      nearThresholdSessions: nearCount,
      avgGapCents,
      estUpliftCents,
      topProductsJson: JSON.stringify(topProducts),
    },
  });

  console.log(
    `Rolled up ${shopId} for ${date.toISOString().slice(0, 10)}: ${cartSessions} cart sessions, ${nearCount} near-threshold.`
  );
}

async function run() {
  const shops = await db.shop.findMany({ select: { id: true } });

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const today = new Date();

  for (const shop of shops) {
    await rollupShopDay(shop.id, yesterday).catch(console.error);
    await rollupShopDay(shop.id, today).catch(console.error);
  }

  await db.$disconnect();
  console.log("Daily rollup complete.");
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
