import { vitePlugin as remix } from "@remix-run/dev";
import { defineConfig, type UserConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";

// Shopify CLI sets HOST; Remix template expects SHOPIFY_APP_URL
if (
  process.env.HOST &&
  (!process.env.SHOPIFY_APP_URL || process.env.SHOPIFY_APP_URL === process.env.HOST)
) {
  process.env.SHOPIFY_APP_URL = process.env.HOST;
  delete process.env.HOST;
}

const host = new URL(process.env.SHOPIFY_APP_URL || "http://localhost").hostname;

let hmrConfig: UserConfig["server"] = {};
if (host === "localhost") {
  hmrConfig = {
    port: 64999,
    strictPort: true,
    hmr: {
      protocol: "ws",
      host: "localhost",
      port: 64999,
    },
  };
} else {
  hmrConfig = {
    strictPort: true,
    hmr: {
      protocol: "wss",
      host,
      port: parseInt(process.env.FRONTEND_PORT || "8002", 10),
    },
  };
}

export default defineConfig({
  server: {
    ...hmrConfig,
    fs: {
      allow: ["app", "node_modules"],
    },
  },
  plugins: [
    remix({
      ignoredRouteFiles: ["**/.*"],
      future: {
        v3_fetcherPersist: true,
        v3_relativeSplatPath: true,
        v3_throwAbortReason: true,
      },
    }),
    tsconfigPaths(),
  ],
  build: {
    assetsInlineLimit: 0,
  },
  optimizeDeps: {
    include: ["@shopify/polaris"],
  },
});
